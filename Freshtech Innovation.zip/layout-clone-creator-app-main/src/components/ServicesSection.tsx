
import React from 'react';

const ServicesSection = () => {
  const services = [
    { title: "Product Design", description: "Creative and user-focused design solutions" },
    { title: "Web Development", description: "Modern and responsive web applications" },
    { title: "App Design", description: "Mobile application design and development" },
    { title: "Coding", description: "Custom software development solutions" },
    { title: "Branding", description: "Brand identity and marketing strategies" },
    { title: "Events & Functions", description: "Professional event management services" }
  ];

  return (
    <section className="bg-blue-800 py-16 px-6" id="services">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold text-center text-white mb-12">
          We provide our customers with<br />top-notch services
        </h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-gray-200 rounded-lg mx-auto mb-4 flex items-center justify-center">
                <div className="w-8 h-8 bg-blue-800 rounded"></div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
              <p className="text-gray-600 text-sm">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
