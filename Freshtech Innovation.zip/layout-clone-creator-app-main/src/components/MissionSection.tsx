
import React from 'react';

const MissionSection = () => {
  return (
    <section className="bg-white py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold text-center text-blue-800 mb-12">Our mission</h2>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-sky-100 rounded-full flex items-center justify-center flex-shrink-0">
                <div className="w-6 h-6 bg-blue-800 rounded-full"></div>
              </div>
              <div>
                <p className="text-gray-700 leading-relaxed">
                  We drive you through technology, top expertise and strong culture to deliver all project through the power of ONE TEAM.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-sky-100 rounded-full flex items-center justify-center flex-shrink-0">
                <div className="w-6 h-6 bg-blue-800 rounded-full"></div>
              </div>
              <div>
                <p className="text-gray-700 leading-relaxed">
                  We strive for exceptional human-centered design and working with our experienced stakeholders.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-sky-100 rounded-full flex items-center justify-center flex-shrink-0">
                <div className="w-6 h-6 bg-blue-800 rounded-full"></div>
              </div>
              <div>
                <p className="text-gray-700 leading-relaxed">
                  We believe people and their ideas drive creating experiences for clients and customers everywhere.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-sky-100 rounded-full flex items-center justify-center flex-shrink-0">
                <div className="w-6 h-6 bg-blue-800 rounded-full"></div>
              </div>
              <div>
                <p className="text-gray-700 leading-relaxed">
                  We believe in the incredibly diverse business talent. Discover an Experience, culture and experiences to tackle new ways of doing business.
                </p>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="bg-blue-800 rounded-lg p-8 text-white">
              <img 
                src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Team collaboration" 
                className="w-full h-64 object-cover rounded-lg mb-4"
              />
              <div className="text-center">
                <button className="bg-white text-blue-800 px-6 py-2 rounded-lg font-semibold mb-2">
                  Start a Virtual Office
                </button>
                <div className="flex justify-center space-x-4 mt-4">
                  <button className="bg-blue-700 text-white px-4 py-2 rounded text-sm">Previous</button>
                  <button className="bg-blue-700 text-white px-4 py-2 rounded text-sm">Next</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MissionSection;
