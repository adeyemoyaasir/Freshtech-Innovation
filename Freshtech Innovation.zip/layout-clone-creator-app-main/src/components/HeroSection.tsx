
import React from 'react';

const HeroSection = () => {
  return (
    <section className="bg-sky-50 py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-4">
          <p className="text-gray-600 text-sm mb-2">Welcome to FreshTech Innovations</p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-left">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6 leading-tight">
              <span className="text-blue-800">Elevate your</span>
              <br />
              <span className="text-blue-800">SKILLS</span>
              <br />
              <span className="text-gray-800">and Business with SkillCraft</span>
              <br />
              <span className="text-gray-800">earning and Services Redefined.</span>
            </h1>
            
            <p className="text-gray-600 mb-8 text-lg">
              We are the Ultimate Learning and Digital Agency Hub
            </p>
            
            <button className="bg-blue-800 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-900 transition-colors">
              Work With Us
            </button>
          </div>
          
          <div className="relative">
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                alt="Team collaboration" 
                className="w-full h-64 object-cover rounded-lg"
              />
              
              {/* Floating skill badges */}
              <div className="absolute -top-4 -left-4 bg-sky-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                Web Dev
              </div>
              <div className="absolute top-8 -right-4 bg-sky-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                Tech Skills
              </div>
              <div className="absolute -bottom-4 left-8 bg-sky-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                Innovation
              </div>
              <div className="absolute bottom-4 -right-8 bg-sky-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                Digital Agency
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
